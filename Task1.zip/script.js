function showMessage()
{
    alert("Welcome to My Simple Webpage!");
}